// Acepta el Reto 409: Seleccionando castellers

import java.util.Scanner;
import java.util.Arrays;

public class SeleccionandoCastellers
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        int casos, grupos, castellers, solucion, i, j;
        int[] alturas;
        
        casos = sc.nextInt();
        
        for(i = 1; i <= casos; i++)
        {
            // Tamaño de los grupos
            grupos = sc.nextInt();
            // Número de castellers
            castellers = sc.nextInt();
            
            // Inicializamos array de alturas y solución
            alturas = new int[castellers];
            solucion = 0;
            
            // Leemos y ordenamos las alturas
            for(j = 0; j < castellers; j++)
            {
                alturas[j] = sc.nextInt();
            }            
            Arrays.sort(alturas);
            
            // Recorremos buscando grupos
            j = 0;
            while(j < castellers)
            {
                // Si las siguientes "grupos" alturas no difieren en más de 15
                // cm, sumamos un grupo más y saltamos al siguiente tras el 
                // grupo
                if(j <= castellers - grupos && 
                   alturas[j + grupos - 1] - alturas[j] <= 15)
                {
                    solucion++;
                    j += grupos;
                }
                // Si no, probamos con el siguiente casteller
                else
                {
                    j++;
                }
            }
            
            System.out.println(solucion);
        }
    }
}
