// Acepta el Reto 282: Agujeros en la manguera

import java.util.Scanner;

public class AgujerosManguera
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        int n, l, distancia, distanciaAnterior, parches;
        
        while(sc.hasNext())
        {
            // Número de agujeros
            n = sc.nextInt();
            // Longitud de los parches
            l = sc.nextInt();
            
            parches = 0;
            distanciaAnterior = 0;
            for(int i = 0; i < n; i++)
            {
                distancia = sc.nextInt();
                // Si es el primer agujero, o se distancia más de L del
                // anterior inicio de parche...
                if(parches == 0 || distancia - distanciaAnterior > l)
                {
                    parches++;
                    distanciaAnterior = distancia;
                }
            }
            
            System.out.println(parches);
        }
    }
}
