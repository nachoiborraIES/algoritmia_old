/**
 * Acepta el reto 284: La tienda de la esquina
 * https://www.aceptaelreto.com/problem/statement.php?id=284
*/

import java.util.Scanner;

public class TiendaEsquina
{	
	
	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		int[] monedas = { 200, 100, 50, 20, 10, 5, 2, 1 };
		int numCasos, compra, pagado, cambio, monedaActual;

		numCasos = sc.nextInt();
		
		for(int i = 0; i < numCasos; i++)
		{
			compra = sc.nextInt();
			pagado = sc.nextInt();
			
			if (pagado < compra)
				System.out.println("DEBE " + (compra - pagado));
			else
			{
				cambio = pagado - compra;
				monedaActual = 0;
				while (monedaActual < monedas.length)
				{
                    // Damos tantas monedas como "quepan" de la actual
					System.out.print(cambio / monedas[monedaActual]);
                    // Descontamos del cambio lo que hemos puesto
					cambio = cambio % monedas[monedaActual];
                    // Pasamos a la siguiente moneda
					monedaActual++;
					if (monedaActual < monedas.length)
						System.out.print(" ");
				}
				
				System.out.println();
			}
		}		
	}
}
