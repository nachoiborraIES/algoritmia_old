// Acepta el Reto 116: Hola mundo

#include <iostream>

using namespace std;

int main()
{
    int veces;

    // Leemos de la entrada el número de veces que nos digan
    cin >> veces;

    // Repetimos esas veces el mensaje
    for(int i = 1; i <= veces; i++)
    {
        cout << "Hola mundo." << endl;
    }
}
