// Acepta el Reto 116: Hola mundo

import java.util.Scanner;

public class Reto116
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        int veces;
        
        veces = sc.nextInt();
        
        for(int i = 1; i <= veces; i++)
        {
            System.out.println("Hola mundo.");
        }
    }
}
