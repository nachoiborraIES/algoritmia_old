# Code Wars: "hello world"
# Copiar y pegar este código en el formulario del intento

def greet():
    return "hello world!"
