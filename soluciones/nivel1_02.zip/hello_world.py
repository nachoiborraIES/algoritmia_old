# Kattis: "Hello World!"

print("Hello World!")
