// Reto 114: Último dígito del factorial

import java.util.Scanner;

public class UltimoDigitoFactorial
{
    static int factorial(int n)
    {
        int resultado;
        
        switch(n)
        {
            case 0:
            case 1:
                resultado = 1;
                break;
            case 2:
                resultado = 2;
                break;
            case 3:
                resultado = 6;
                break;
            case 4:
                resultado = 4;
                break;
            default:
                resultado = 0;
                break;
        }
        
        return resultado;
    }    
    
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        int n, numero;
        
        n = sc.nextInt();
        
        for(int i = 1; i <= n; i++)
        {
            numero = sc.nextInt();
            System.out.println(factorial(numero));
        }
    }
}
