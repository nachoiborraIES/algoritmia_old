/*
 * Acepta el reto 168: La pieza perdida
 * https://aceptaelreto.com/problem/statement.php?id=168
 * Versión que usa la suma de Gauss para mejorar la eficiencia
 */ 

import java.util.Scanner;
import java.util.Arrays;

public class PiezaPerdida
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        int totalPiezas, sumaTotal, sumaParcial, pieza;
        
        do
        {
            totalPiezas = sc.nextInt();
            
            if(totalPiezas != 0)
            {
                sumaTotal = 0;
                sumaParcial = 0;
                
                // Sumar 1+2+3+...+totalPiezas usando suma de Gauss
                sumaTotal = (totalPiezas + 1) * totalPiezas / 2;
                
                // Leer totalPiezas-1 y sumarlas
                for(int i = 1; i <= totalPiezas - 1; i++)
                {
                    pieza = sc.nextInt();
                    sumaParcial = sumaParcial + pieza;
                }
                
                // Calcular resta
                System.out.println(sumaTotal - sumaParcial);
            }            
        }
        while(totalPiezas != 0);
    }
}
