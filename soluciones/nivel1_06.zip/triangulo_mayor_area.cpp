// Acepta el Reto 350: El triángulo de mayor área

#include <iostream>

using namespace std;

int main()
{
    float a, b, area;

    do
    {
        cin >> a >> b;
        if(a != 0 || b != 0)
        {
            area = a * b / 2;
            printf("%.1f\n", area);
        }
    }
    while(a != 0 || b != 0);
    
    return 0;
}
