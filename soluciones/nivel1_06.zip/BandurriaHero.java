// Acepta el Reto 364: Bandurria Hero

import java.util.Scanner;

public class BandurriaHero
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        int casos, totalPuntos, puntosActuales;    
        String linea;

        // Leemos el número de casos y el salto de línea posterior
        casos = sc.nextInt();
        sc.nextLine();

        for(int i = 0; i < casos; i++)
        {
            // Leemos el caso de prueba
            linea = sc.nextLine();
            // Inicializamos contadores de puntos para este caso
            totalPuntos = puntosActuales = 0;

            // Leemos del inicio al fin del string
            for(int j = 0; j < linea.length(); j++)
            {
                // Con charAt(j) accedemos a cada carácter
                if(linea.charAt(j) == 'O')
                {
                    // Si es una O incrementamos el 10 los puntos
                    // de la nota actual
                    puntosActuales += 10;
                    // Acumulamos los puntos
                    totalPuntos += puntosActuales;
                }
                else
                {
                    // Si es un punto reseteamos la puntuación acumulada a 0
                    puntosActuales = 0;
                }
            }

            System.out.println(totalPuntos);
        }
    }
}
