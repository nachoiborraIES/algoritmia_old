
// Acepta el Reto 576: Leyendo el diccionario

import java.util.Scanner;

public class LeyendoDiccionario
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        int segundosPalabra, numEntradas, totalEntradas, horas, minutos, segundos;

        do
        {
            segundosPalabra = sc.nextInt();
            if(segundosPalabra != 0)
            {
                // Procesamos la línea con las entradas por página
                totalEntradas = 0;
                do
                {
                    // Vamos leyendo hasta encontrar un 0
                    // y acumulando en el total de entradas
                    numEntradas = sc.nextInt();
                    if(numEntradas != 0)
                    {
                        totalEntradas += numEntradas;
                    }
                }
                while(numEntradas != 0);

                // Calculamos tiempo total en segundos
                segundos = totalEntradas * segundosPalabra;
                // Calculamos horas
                horas = segundos / 3600;
                // Calculamos minutos
                minutos = (segundos % 3600) / 60;
                // Calculamos segundos
                segundos = (segundos % 3600) % 60;

                // Mostramos resultado
                System.out.printf("%02d:%02d:%02d\n", horas, minutos, segundos);
            }
        }
        while(segundosPalabra != 0);
    }
}
