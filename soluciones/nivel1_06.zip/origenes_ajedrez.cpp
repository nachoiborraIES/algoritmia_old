// Acepta el Reto 236: Los orígenes del ajedrez

#include <iostream>

using namespace std;

int main()
{
    long long int granosIniciales, incremento, casillas, granosCasilla, suma;

    do
    {
        cin >> granosIniciales >> incremento >> casillas;

        if (granosIniciales != 0 || incremento != 0 || casillas != 0)
        {
            // Contamos al inicio los granos de la primera casilla
            suma = granosCasilla = granosIniciales;

            // Recorremos el resto de casillas (desde la segunda)
            for (int i = 2; i <= casillas; i++)
            {
                // Calculamos los granos que van a esa casilla según los
                // de la casilla anterior (por el incremento)
                granosCasilla = granosCasilla * incremento;
                // Acumulamos los granos de esa casilla en la suma total
                suma += granosCasilla;
            }

            cout << suma << endl;
        }
    } while (granosIniciales != 0 || incremento != 0 || casillas != 0);

    return 0;
}
