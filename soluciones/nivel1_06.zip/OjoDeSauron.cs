// Eye of Sauron
// https://open.kattis.com/problems/eyeofsauron

using System;

class Ejercicio
{
    static void Main()
    {
        int izq = 0, der = 0;
        bool cambio = false;
        string entrada = Console.ReadLine();
        foreach(char letra in entrada)
        {
            if(letra == '|')
            {
                if(cambio)
                {
                    der++;
                }
                else
                {
                    izq++;
                }
            }
            else
            {
                cambio = true;
            }
        }
        
        if(izq == der)
        {
            Console.WriteLine("correct");
        }
        else
        {
            Console.WriteLine("fix");
        }
    }
}