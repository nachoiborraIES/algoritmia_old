// Acepta el Reto 576: Leyendo el diccionario

#include <iostream>

using namespace std;

int main() 
{
    int segundosPalabra, numEntradas, totalEntradas, horas, minutos, segundos;

    do
    {
        cin >> segundosPalabra;
        if(segundosPalabra != 0)
        {
            // Procesamos la línea con las entradas por página
            totalEntradas = 0;
            do
            {
                // Vamos leyendo hasta encontrar un 0
                // y acumulando en el total de entradas
                cin >> numEntradas;
                if(numEntradas != 0)
                {
                    totalEntradas += numEntradas;
                }
            }
            while(numEntradas != 0);

            // Calculamos tiempo total en segundos
            segundos = totalEntradas * segundosPalabra;
            // Calculamos horas
            horas = segundos / 3600;
            // Calculamos minutos
            minutos = (segundos % 3600) / 60;
            // Calculamos segundos
            segundos = (segundos % 3600) % 60;

            // Mostramos resultado
            printf("%02d:%02d:%02d\n", horas, minutos, segundos);
        }
    }
    while(segundosPalabra != 0);

    return 0;
}
