// Metronome
// https://open.kattis.com/problems/metronome

using System;

class Ejercicio
{
    static void Main()
    {
        int n = Convert.ToInt32(Console.ReadLine());
        double rev = n / 4f;
        Console.WriteLine(rev.ToString("#.0#"));
    }
}