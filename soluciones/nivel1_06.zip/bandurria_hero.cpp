// Acepta el Reto 364: Bandurria Hero

#include <iostream>

using namespace std;

int main()
{
    int casos, totalPuntos, puntosActuales;    
    string linea;

    // Leemos el número de casos
    cin >> casos;

    for(int i = 0; i < casos; i++)
    {
        // Leemos el caso de prueba
        cin >> linea;
        // Inicializamos contadores de puntos para este caso
        totalPuntos = puntosActuales = 0;

        // Leemos del inicio al fin del string
        for(int j = 0; j < linea.length(); j++)
        {
            if(linea[j] == 'O')
            {
                // Si es una O incrementamos el 10 los puntos
                // de la nota actual
                puntosActuales += 10;
                // Acumulamos los puntos
                totalPuntos += puntosActuales;
            }
            else
            {
                // Si es un punto reseteamos la puntuación acumulada a 0
                puntosActuales = 0;
            }
        }

        cout << totalPuntos << endl;
    }
}
