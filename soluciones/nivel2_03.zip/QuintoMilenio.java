// Reto 178: Quinto milenio

import java.util.Scanner;

public class QuintoMilenio
{		
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        int casos, indiceTexto, indiceMensaje;
        boolean encontrado;
        String texto, mensajeSecreto;
        
        casos = sc.nextInt();
        // Leer el salto de línea tras el número de casos
        sc.nextLine();
        
        for (int i = 0; i < casos; i++)
        {
            texto = sc.nextLine().toUpperCase();
            mensajeSecreto = sc.nextLine().toUpperCase();
            
            indiceMensaje = indiceTexto = 0;
            encontrado = false;
            
            // Tratamos de buscar cada carácter del mensaje secreto en el texto,
            // en el orden correcto. Exploramos el texto desde el
            // principio, y buscamos cada carácter del texto secreto
            
            while(indiceTexto < texto.length() && !encontrado)
            {
                if (mensajeSecreto.charAt(indiceMensaje) == 
                    texto.charAt(indiceTexto))
                {
                    do
                    {
                        indiceMensaje++;
                    } while (indiceMensaje < mensajeSecreto.length() && 
                        mensajeSecreto.charAt(indiceMensaje) == ' ');
                }
                if (indiceMensaje == mensajeSecreto.length())
                {
                    encontrado = true;
                }
                indiceTexto++;
            }
            
            if(encontrado)
            {
                System.out.println("SI");
            } else {
                System.out.println("NO");
            }
        }    
    }
}
