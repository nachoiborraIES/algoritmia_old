// Kattis: Simon says

using System;

class Ejercicio
{
    static void Main()
    {
        const string INICIO = "Simon says ";
        int casos;
        string frase;
        
        casos = Convert.ToInt32(Console.ReadLine());
        
        for(int i = 1; i <= casos; i++)
        {
            frase = Console.ReadLine();
            if(frase.StartsWith(INICIO))
            {
                Console.WriteLine(frase.Substring(INICIO.Length));
            }
        }
    }
}
