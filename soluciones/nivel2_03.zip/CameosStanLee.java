// Reto 475: Cameos de Stan Lee

import java.util.Scanner;

public class CameosStanLee 
{		
    // Guardamos en una constante el texto a buscar
	public static final String STANLEE = "stanlee";
	
    public static void main(String[] args) 
    {
        Scanner sc = new Scanner(System.in);
		int casos, pos, cont;
		String texto;
        
        casos = sc.nextInt();
        // Leemos el salto de línea tras el número de casos
        sc.nextLine();
        
        for (int i = 0; i < casos; i++)
        {
			texto = sc.nextLine().toLowerCase();
			cont = 0;
			pos = 0;
			
			for (int j = 0; j < texto.length(); j++)
			{
				if (texto.charAt(j) == STANLEE.charAt(pos))
				{
                    // Hemos encontrado una letra. Pasamos a la siguiente
					pos++;
					if (pos == STANLEE.length())
					{
                        // Hemos encontrado una ocurrencia completa
						cont++;
						pos = 0;
					}
				}				
			}
			
			System.out.println(cont);
		}		
    }    
}
