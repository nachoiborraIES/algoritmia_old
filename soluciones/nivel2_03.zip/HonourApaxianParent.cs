// Kattis: Honour (thy) Apaxian Parent

using System;

class Ejercicio
{
    static void Main()
    {
        string[] nombres = Console.ReadLine().Split(' ');
        string resultado;
        
        if(nombres[0].EndsWith("e"))
        {
            resultado = nombres[0] + "x" + nombres[1];
        }
        else if (nombres[0].EndsWith("a") || nombres[0].EndsWith("i") ||
            nombres[0].EndsWith("o") || nombres[0].EndsWith("u"))
        {
            resultado = nombres[0].Substring(0, nombres[0].Length-1) + "ex" + 
                nombres[1];
        }
        else if(nombres[0].EndsWith("ex"))
        {
            resultado = nombres[0] + nombres[1];
        }
        else
        {
            resultado = nombres[0] + "ex" + nombres[1];
        }
        Console.WriteLine(resultado);
    }
}
