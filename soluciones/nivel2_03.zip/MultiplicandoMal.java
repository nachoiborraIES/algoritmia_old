// Acepta el Reto 466: Multiplicando mal

import java.util.*;

public class MultiplicandoMal
{
    public static void main(String[] args) 
    {
		Scanner sc = new Scanner(System.in);
        int casos, indice, maxLongitud, acarreo, resultParcial;
        String[] numeros;
        String resultado;
		
		casos = sc.nextInt();
        // Leemos salto de línea tras el número de casos
		sc.nextLine();

		for (int i = 0; i < casos; i++)
		{
            // Leemos los dos números en una línea
			numeros = sc.nextLine().split(" ");
		
            // Nos quedamos con la longitud más larga de los dos y 
            // rellenamos el otro número con ceros por la izquierda
			maxLongitud = Math.max(numeros[0].length(), numeros[1].length());
            while(numeros[0].length() < maxLongitud)
                numeros[0] = "0" + numeros[0];
            while(numeros[1].length() < maxLongitud)
                numeros[1] = "0" + numeros[1];
			
            // Comenzamos multiplicando por el límite derecho
			indice = maxLongitud - 1;
			acarreo = 0;
			resultado = "";
			
			while (indice >= 0)
			{
                // Para obtener el valor numérico de cada "char" le restamos
                // el código ASCII del 0
				resultParcial = (numeros[0].charAt(indice) - '0') * 
                    (numeros[1].charAt(indice) - '0');
				resultParcial += acarreo;
				resultado = (resultParcial % 10) + resultado;
				acarreo = resultParcial / 10;
				indice--;
			}
			
			if (acarreo > 0)
				resultado = acarreo + resultado;
			
			System.out.println(resultado);
		}
	}    
}
