// Kattis: Code to save lives

using System;

class Ejercicio
{
    static void Main()
    {
        int casos, maxLongitud, indice, acarreo, resultParcial;
        string num1, num2, resultado;
        
        casos = Convert.ToInt32(Console.ReadLine());
        
        for(int i = 1; i <= casos; i++)
        {
            num1 = Console.ReadLine();
            num2 = Console.ReadLine();
            
            // Rellenamos con ceros (y espacios) el número más corto
            maxLongitud = Math.Max(num1.Length, num2.Length);
            while(num1.Length < maxLongitud)
                num1 = "0 " + num1;
            while(num2.Length < maxLongitud)
                num2 = "0 " + num2;
                
            // Convertimos cada número en un array de dígitos
            string[] digitos1 = num1.Split(' ');
            string[] digitos2 = num2.Split(' ');
            
            // Vamos recorriendo y sumando de derecha a izquierda
            indice = digitos1.Length - 1;
            acarreo = 0;
            resultado = "";
            while(indice >= 0)
            {
				resultParcial = Convert.ToInt32(digitos1[indice]) + 
                    Convert.ToInt32(digitos2[indice]);
				resultParcial += acarreo;
				resultado = (resultParcial % 10) + resultado;
				acarreo = resultParcial / 10;
				indice--;
			}
			
			if (acarreo > 0)
				resultado = acarreo + resultado;
			
            for(int j = 0; j < resultado.Length; j++)
            {
                if (j != 0)
                    Console.Write(" ");
                Console.Write(resultado[j]);
            }
            Console.WriteLine();
        }
    }
}
