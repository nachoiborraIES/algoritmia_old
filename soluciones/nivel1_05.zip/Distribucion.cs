// Kattis: Arrangement

using System;

class Ejercicio
{
    static void Main()
    {
        int m, n, equiposSala, resto;
        
        n = Convert.ToInt32(Console.ReadLine());
        m = Convert.ToInt32(Console.ReadLine());

        equiposSala = m / n;
        resto = m % n;

        // Recorremos cada sala
        for (int i = 1; i<= n; i++)
        {
            // Imprimimos cuántos equipos van en cada sala
            for (int j = 1; j < equiposSala; j++)
            {
                Console.Write("*");
                // Si sobran equipos, añadimos uno en cada sala hasta que
                // se acaben
                if (resto > 0)
                {
                    Console.Write("*");
                    resto--;
                }
            }
            Console.WriteLine();
        }
    }
}
