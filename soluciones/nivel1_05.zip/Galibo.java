// Acepta el reto 664: Gálibo

import java.util.Scanner;

public class Galibo
{       
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        int puentes, carriles, altura, maxPuente, resultado;
        
        do
        {
            puentes = sc.nextInt();
            
            if(puentes != 0)
            {
                resultado = 0;
                for(int i = 1; i <= puentes; i++)
                {
                    maxPuente = 0;
                    carriles = sc.nextInt();
                    for(int j = 0; j < carriles; j++)
                    {
                        altura = sc.nextInt();
                        if(maxPuente == 0 || altura > maxPuente)
                        {
                            maxPuente = altura;
                        }
                    }
                    
                    if(resultado == 0 || maxPuente < resultado)
                    {
                        resultado = maxPuente;
                    }
                }
                
                System.out.println(resultado);
            }
        }
        while(puentes != 0);
    }
}
