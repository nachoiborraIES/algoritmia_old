// Acepta el Reto 158: Los saltos de Mario

#include <iostream>

using namespace std;

int main()
{
    int casos, muros, arriba, abajo, previo, actual;
    
    cin >> casos;
    
    // Procesamos cada caso de prueba
    for(int i = 1; i <= casos; i++)
    {
        // Leemos la cantidad de muros
        cin >> muros;
        // Aún no hemos hecho ningún salto desde un muro previo
        // en esta tanda
        previo = -1;
        // Contadores de saltos ascendentes y descendentes
        arriba = abajo = 0;
        // Segundo bucle: leemos los muros de este caso
        for(int j = 0; j < muros; j++)
        {
            cin >> actual;
            // Miramos si venimos de una torre previa
            // y si es un salto arriba o abajo
            if (previo >= 0 && actual > previo)
                arriba++;
            else if (previo >= 0 && actual < previo)
                abajo++;
            previo = actual;
        }

        cout << arriba << " " << abajo << endl;
    }  

    return 0;
}
