n = int(input())
m = int(input())

equipos_sala = m // n
resto = m % n

for i in range(0, n):
    for j in range(0, equipos_sala):
        print('*', end='')
    if resto > 0:
        print('*', end='')
        resto -= 1
    print()