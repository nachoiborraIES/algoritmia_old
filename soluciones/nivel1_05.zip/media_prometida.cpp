// Acepta el Reto 622: La media prometida

#include <iostream>

using namespace std;

int main()
{
    int examenesHechos, examen, sumaExamenes, mediaPrometida, solucion;
    
    do
    {
        cin >> examenesHechos;
        if(examenesHechos != 0)
        {
            sumaExamenes = 0;
            for (int i = 0; i < examenesHechos; i++)
            {
                cin >> examen;
                sumaExamenes += examen;
            }
            cin >> mediaPrometida;
            solucion = mediaPrometida * (examenesHechos + 1) - sumaExamenes;
            if (solucion >= 0 && solucion <= 10)
            {
                cout << solucion << endl;
            }
            else
            {
                cout << "IMPOSIBLE" << endl;
            }
        }
    }
    while(examenesHechos != 0);
    
    return 0;
}
