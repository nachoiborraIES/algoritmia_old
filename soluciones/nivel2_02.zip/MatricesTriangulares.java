// Acepta el Reto 160: Matrices triangulares

import java.util.Scanner;

public class MatricesTriangulares
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        int filas;
        boolean cerosArriba, cerosAbajo;

        do
        {
            filas = sc.nextInt();
            
            if (filas > 0)
            {
                cerosArriba = cerosAbajo = true;
                int[][] matriz = new int[filas][filas];
                // Comprobamos si hay algo que no sea cero en el triángulo
                // superior o inferior, y actualizamos el booleano
                for (int i = 0; i < filas; i++)
                    for (int j = 0; j < filas; j++)
                    {
                        matriz[i][j] = sc.nextInt();
                        if (j > i && cerosArriba && matriz[i][j] != 0)
                            cerosArriba = false;
                        else if (j < i && cerosAbajo && matriz[i][j] != 0)
                            cerosAbajo = false;
                    }
                        
                System.out.println((cerosArriba || cerosAbajo)?"SI":"NO");
            }
        } 
        while (filas > 0);	
    }
}
