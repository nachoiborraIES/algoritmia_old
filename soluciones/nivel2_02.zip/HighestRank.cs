using System;

public class Kata
{
    public static int HighestRank(int[] arr)
    {
        Array.Sort(arr);
        int veces = 0, maxVeces = 0, num = 0;
        for(int i = 0; i < arr.Length; i++)
        {
            if(i != 0 && arr[i] != arr[i-1])
            {
                if(veces > maxVeces || veces == maxVeces && arr[i] > num)
                {
                    num = arr[i-1];
                    maxVeces = veces;
                }
                veces = 0;
            }
            veces++;
        }
    
        if(veces > maxVeces || veces == maxVeces && arr[arr.Length - 1] > num)
        {
            num = arr[arr.Length - 1];
        }
    
        return num;
    }
  
    static void Main()
    {
        int[] datos = {12, 10, 8, 8, 3, 3, 3, 3, 2, 4, 10, 12, 10};
        Console.WriteLine(HighestRank(datos));
    }
}
