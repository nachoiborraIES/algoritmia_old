/**
 * Acepta el reto 485: Senda pirenaica
 * https://www.aceptaelreto.com/problem/statement.php?id=485
*/

import java.util.Scanner;

public class SendaPirenaica
{
    public static void main(String[] args)
    {        
        Scanner sc = new Scanner(System.in);
        int numEtapas, suma;

        do
        {
            numEtapas = sc.nextInt();
            
            if (numEtapas > 0)
            {            
                int[] distancias = new int[numEtapas];
                suma = 0;
                
                // Leer distancias y sumarlas
                
                for (int i = 0; i < numEtapas; i++)
                {
                    distancias[i] = sc.nextInt();
                    suma += distancias[i];
                }
                
                // Recorrer distancias y resolver el problema
                
                for (int i = 0; i < numEtapas; i++)
                {
                    System.out.print(suma);
                    if (i < numEtapas - 1)
                        System.out.print(" ");
                    suma -= distancias[i];
                }                
                
                System.out.println();
            }
        } 
        while (numEtapas > 0);
    }    
}
