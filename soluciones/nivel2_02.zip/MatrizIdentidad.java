// Reto 151: ¿Es una matriz identidad?

import java.util.Scanner;

public class MatrizIdentidad
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        int n;
        int[][] datos;
        boolean esIdentidad;
        
        do
        {
            n = sc.nextInt();
            if(n != 0)
            {
                // Creamos la matriz del tamaño indicado
                datos = new int[n][n];
                // Leemos cada fila
                for(int i = 0; i < n; i++)
                {
                    // Leemos cada columna de la fila
                    for(int j = 0; j < n; j++)
                    {
                        datos[i][j] = sc.nextInt();
                    }
                }
                
                // Ya tenemos la matriz leída.
                // Vemos si es identidad
                
                // Suponemos al inicio que sí lo es
                esIdentidad = true;
                
                // Recorremos cada casilla de la matriz
                // y vemos si no es identidad
                for(int i = 0; i < n; i++)
                {
                    for(int j = 0; j < n; j++)
                    {
                        // Diagonal principal: i == j
                        if (i == j && datos[i][j] != 1)
                        {
                            esIdentidad = false;
                        }
                        // Fuera de diagonal principal
                        else if (i != j && datos[i][j] != 0)
                        {
                            esIdentidad = false;
                        }
                    }
                }
                
                if(esIdentidad)
                {
                    System.out.println("SI");
                }
                else
                {
                    System.out.println("NO");
                }
            }
        }
        while(n != 0);
    }
}
