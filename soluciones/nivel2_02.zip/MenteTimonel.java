/**
 * Acepta el reto 458: En la mente del timonel
 * https://www.aceptaelreto.com/problem/statement.php?id=458
*/

import java.util.Scanner;
import java.util.Arrays;

public class MenteTimonel
{
    public static void main(String[] args) 
    {
        Scanner sc = new Scanner(System.in);
        int maxNumeros;
        long[] numeros;

		do
		{
			maxNumeros = sc.nextInt();
			if (maxNumeros > 0)
			{
				numeros = new long[maxNumeros];
				for (int i = 0; i < maxNumeros; i++)
					numeros[i] = sc.nextLong();
					
				Arrays.sort(numeros);
				
				System.out.println(Math.max(numeros[0] * numeros[1], numeros[maxNumeros-2] * numeros[maxNumeros-1]));
			}
		} while (maxNumeros > 0);        
    }    
}
