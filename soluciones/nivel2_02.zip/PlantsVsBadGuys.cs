// Kattis: Plants vs Bad Guys

using System;

class Ejercicio
{
    static void Main()
    {
        int filas, solucion = 0;
        string[] plantas;

        filas = Convert.ToInt32(Console.ReadLine());
        plantas = Console.ReadLine().Split(' ');
        // Buscamos la fila que tiene menos plantas
        solucion = Convert.ToInt32(plantas[0]);
        for(int i = 1; i < plantas.Length; i++)
        {
            int numero = Convert.ToInt32(plantas[i]);
            if (numero < solucion)
                solucion = numero;
        }
        
        // Hará falta una horda más que las plantas de la fila más pequeña
        Console.WriteLine(solucion+1);
    }
}