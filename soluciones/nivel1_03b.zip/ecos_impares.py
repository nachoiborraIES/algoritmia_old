# Kattis: "Odd echo"

num_palabras = int(input())

for i in range(1, num_palabras+1):
    palabra = input()
    if i % 2 != 0:
        print(palabra)
