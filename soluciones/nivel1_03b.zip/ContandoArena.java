// Acepta el Reto 369: Contando en la arena

import java.util.Scanner;

public class ContandoArena
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        int num;
        do
        {
            num = sc.nextInt();
            if (num > 0)
            {
                for (int i = 1; i <= num; i++)
                {
                    System.out.print(1);
                }
                System.out.println();
            }
        } while (num > 0);
    }
}
