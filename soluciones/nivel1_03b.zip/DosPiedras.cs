// Kattis: "Take Two Stones"

using System;

class Ejercicio
{
    static void Main()
    {
        int n = Convert.ToInt32(Console.ReadLine());
        if (n % 2 == 0)
        {
            Console.WriteLine("Bob");
        }
        else
        {
            Console.WriteLine("Alice");
        }
    }
}
