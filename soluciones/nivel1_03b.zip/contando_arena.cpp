// Acepta el Reto 369: Contando en la arena

#include <iostream>

using namespace std;

int main()
{
	int num;
	do
	{
		cin >> num;
		if (num > 0)
		{
			for (int i = 1; i <= num; i++)
				cout << 1;
			cout << endl;
		}
	} while (num > 0);
 	return 0;
}
