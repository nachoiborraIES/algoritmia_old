# Kattis: "FYI"

numero = int(input())
prefijo = numero // 10000 # División entera

if prefijo == 555:
    print(1)
else:
    print(0)
