// Kattis: "FYI"

using System;

class Ejercicio
{
    static void Main()
    {
        int numero = Convert.ToInt32(Console.ReadLine());
        int prefijo = numero / 10000;
        if(prefijo == 555)
        {
            Console.WriteLine(1);
        }
        else
        {
            Console.WriteLine(0);
        }
    }
}
