// Acepta el Reto 413: "Claras y oscuras"

#include <iostream>

using namespace std;

int main()
{
    int casos, ancho, largo, total, claras, oscuras;

    // Determinamos el número de casos de prueba
    cin >> casos;

    for(int i = 1; i <= casos; i++)
    {
        // Leemos ancho y alto del caso actual
        cin >> ancho;
        cin >> largo;

        // Calculamos total de losetas
        total = ancho * largo;

        // Determinamos losetas claras y oscuras según
        // si es par o impar el total
        claras = oscuras = total / 2;
        if (total % 2 != 0)
        {
            claras++;
        }

        // Resultado
        cout << claras << " " << oscuras << endl;
    }
}
