// Acepta el Reto 413: "Claras y oscuras"

import java.util.Scanner;

public class ClarasOscuras
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        int casos, ancho, largo, total, claras, oscuras;
        
        casos = sc.nextInt();
        
        for(int i = 1; i <= casos; i++)
        {
            ancho = sc.nextInt();
            largo = sc.nextInt();
            total = ancho * largo;
            claras = oscuras = total / 2;
            if(total % 2 != 0)
            {
                claras++;
            }
            
            System.out.println(claras + " " + oscuras);
        }
    }
}
