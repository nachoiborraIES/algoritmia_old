// Acepta el Reto 362: El día de Navidad

#include <iostream>

using namespace std;

int main()
{
    int numFechas, dia, mes;

    cin >> numFechas;

    for (int i = 1; i <= numFechas; i++)
    {
        cin >> dia >> mes;
        
        if(dia == 25 && mes == 12)
            cout << "SI" << endl;
        else
            cout << "NO" << endl;
    }

    return 0;
}
