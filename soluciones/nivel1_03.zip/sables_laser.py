# Code Wars: "How many lightsabers do you own?"
# Copiar y pegar el siguiente código en el formulario del intento

def how_many_light_sabers_do_you_own(name=None):
    result = 0
    if name == "Zach":
        result = 18
    return result
