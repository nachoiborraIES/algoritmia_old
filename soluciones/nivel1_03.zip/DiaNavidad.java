// Acepta el Reto 362: El día de Navidad

import java.util.Scanner;

public class Reto362
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        int numFechas, dia, mes;

        // Leemos el número de fechas que nos van a pasar
        numFechas = sc.nextInt();

        // Repetimos el bucle para leer ese número de fechas
        for(int i = 1; i <= numFechas; i++)
        {
            // Leemos día y mes por separado
            dia = sc.nextInt();
            mes = sc.nextInt();

            // Comprobamos si es el día de Navidad
            if(dia == 25 && mes == 12)
            {
                System.out.println("SI");
            }
            else
            {
                System.out.println("NO");
            }
        }
    }
}
